/**
 * Auteur 
 * Maxime Champagne
 * 3 mars 2022
 * 
 * Modifi� par
 *
 *
 * SPI/main.c
 * 
*/
#include <stdio.h>
#include "mcc_generated_files/mcc.h"
#define MAX 60
#define VALUE_20HZ 0xCBF0

// Definiton de enum pour les ondes
typedef enum {
    SINUSOIDAL,
    SQUARE,
    TRIANGULAR
} FormeOnde;

 FormeOnde selectedWaveform = SINUSOIDAL; // (initialisattion)

uint8_t const sin[MAX] ={
              254,254,252,249,244,238,231,222,213,202,
              191,179,167,154,141,127,114,101,88,76,
              64,53,42,33,24,17,11,6,3,1,
              0,1,3,6,11,17,24,33,42,53,
              64,76,88,101,114,128,141,154,167,179,
              191,202,213,222,231,238,244,249,252,254};

uint8_t const car[MAX] ={
             0,0,0,0,0,0,0,0,0,0,
			  0,0,0,0,0,0,0,0,0,0,
			  0,0,0,0,0,0,0,0,0,0,
			  255,255,255,255,255,255,255,255,255,255,
			  255,255,255,255,255,255,255,255,255,255,
			  255,255,255,255,255,255,255,255,255,255};

uint8_t const tri[MAX] ={
            9,17,26,34,43,51,60,68,77,85,
			 94,102,111,119,128,136,145,153,162,170,
			 179,187,196,204,213,221,230,238,247,255,
			 247,238,230,221,213,204,196,187,179,170,
			 162,153,145,136,128,119,111,102,94,86,
			 77,68,60,51,43,34,26,17,9,0};



void out_dig(uint8_t x);
void sinus_60(void);
void car_60(void);
void tri_60(void);
void myTimer1_ISR(void);

/*
                         Main application
 */
void main(void)
{
    uint8_t valeur, lecture;
    float tension;
    
    SYSTEM_Initialize();
    
//    INTERRUPT_GlobalInterruptEnable();
//    INTERRUPT_PeripheralInterruptEnable();
//    
//    TMR1_SetInterruptHandler(myTimer1_ISR);

    SSPCON1bits.SSPEN = 1;
    IO_RA5_SetHigh();
    
   while (1)
    {
            
            switch(selectedWaveform) 
            {    
                
                case SINUSOIDAL: 
                sinus_60(); // Generate sinusoidal waveform
                lecture = EUSART1_Read();
                if (lecture == 'T')
                {
                    selectedWaveform = TRIANGULAR;
                }
                if (lecture == 'C')
                {
                    selectedWaveform = SQUARE;
                }
                break;

            case SQUARE:
                
                car_60(); // Generate square waveform
                lecture = EUSART1_Read();
                if (lecture == 'S')
                {
                    selectedWaveform = SINUSOIDAL ;
                }
                if (lecture == 'T')
                {
                    selectedWaveform = TRIANGULAR;
                }
                break;

            case TRIANGULAR:
                
                tri_60(); // Generate triangular waveform
                lecture = EUSART1_Read();
                if (lecture == 'S')
                {
                    selectedWaveform = SINUSOIDAL;
                }
                if (lecture == 'C') 
                {
                    selectedWaveform = SQUARE;
                }
                break;
            }  
    }   
} 

//---------------------------------------------------------------
// Routine d'interruption du Timer1
//---------------------------------------------------------------
void myTimer1_ISR(void)
{
    static uint8_t i; 
    
    TMR1_WriteTimer(0xCBF0);
    
    out_dig(sin[i]);
    
    i++;
    if (i==MAX)
    {
        i=0;
    }
}
//---------------------------------------------------------------------------//

//---------------------------------------------------------------------------//

//----------------------------------------------------------------
// Transmission au pot. d'une onde comprenant 60 points par cycle.
//----------------------------------------------------------------
void sinus_60(void)
{
    uint8_t i;
    while(!EUSART1_is_rx_ready()) 
    {
        for (i=0;i<MAX;i++) 
        {
            out_dig(sin[i]);
			__delay_us(830);
        }
    } 
}
//----------------------------------------------------------------
// Transmission au pot. d'une onde carr�e comprenant 60 points par cycle.
//----------------------------------------------------------------
void car_60(void) 
{
    uint8_t i;
    while(!EUSART1_is_rx_ready()) 
    {
        for (i = 0; i < MAX; i++)
        {
            out_dig(car[i]);
            __delay_us(830);
        }
    }
}

//----------------------------------------------------------------
// Transmission au pot. d'une onde triangulaire comprenant 60 points par cycle.
//----------------------------------------------------------------
void tri_60(void)
{
    uint8_t i;
    while(!EUSART1_is_rx_ready()) 
    {
        for (i = 0; i < MAX; i++) 
        {
            out_dig(tri[i]);
            __delay_us(833);
        }
    }
}


//----------------------------------------------------------------
//  Transmission d'une donnee a la sortie du pot. numerique
//----------------------------------------------------------------
void out_dig(uint8_t x)
{
	IO_RA5_SetLow();   // selection du potentiometre
	SPI_ExchangeByte(0x11);  // ecriture, pot. 0
	SPI_ExchangeByte(x);
	IO_RA5_SetHigh();
	//__delay_ms(1);
}
